document.getElementById('convert-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const amount = document.getElementById('amount').value;
    const fromCurrency = document.getElementById('from-currency').value;
    const toCurrency = document.getElementById('to-currency').value;

    const response = await fetch(`/convert?amount=${amount}&from=${fromCurrency}&to=${toCurrency}`);
    const result = await response.json();

    document.getElementById('conversion-result').innerText = `Resultado: ${result.convertedAmount} ${toCurrency}`;
});

document.getElementById('trade-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const amount = document.getElementById('trade-amount').value;
    const currency = document.getElementById('trade-currency').value;

    const response = await fetch(`/trade?amount=${amount}&currency=${currency}`);
    const result = await response.json();

    document.getElementById('trade-result').innerText = `Resultado: ${result.status}`;
});