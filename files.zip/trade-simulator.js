const express = require('express');
const app = express();
const port = 3002;

app.get('/trade', (req, res) => {
    const { amount, currency } = req.query;
    // Aquí puedes añadir lógica para simular la compra/venta
    res.json({ status: `Simulación completada para ${amount} ${currency}` });
});

app.listen(port, () => {
    console.log(`Trade Simulator Service running on port ${port}`);
});